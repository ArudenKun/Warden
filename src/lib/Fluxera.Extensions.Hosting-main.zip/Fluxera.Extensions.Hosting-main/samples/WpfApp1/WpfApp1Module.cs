﻿namespace WpfApp1
{
	using Fluxera.Extensions.Hosting.Modules;

	public class WpfApp1Module : ConfigureServicesModule
	{
	}
}
