[assembly: System.Runtime.Versioning.SupportedOSPlatform("browser")]
