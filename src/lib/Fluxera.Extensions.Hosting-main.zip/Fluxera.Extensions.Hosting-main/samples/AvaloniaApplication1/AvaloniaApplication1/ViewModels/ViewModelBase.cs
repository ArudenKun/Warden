﻿namespace AvaloniaApplication1.ViewModels
{
	using CommunityToolkit.Mvvm.ComponentModel;

	public abstract class ViewModelBase : ObservableObject
	{
	}
}
