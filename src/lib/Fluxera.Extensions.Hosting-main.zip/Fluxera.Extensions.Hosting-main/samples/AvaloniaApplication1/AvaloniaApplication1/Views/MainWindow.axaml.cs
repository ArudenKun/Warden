namespace AvaloniaApplication1.Views
{
	using Avalonia.Controls;

	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}