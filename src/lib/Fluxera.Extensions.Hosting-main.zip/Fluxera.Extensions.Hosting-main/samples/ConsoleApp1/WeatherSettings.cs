﻿namespace ConsoleApp1
{
	internal sealed class WeatherSettings
	{
		public string Unit { get; set; }
	}
}
