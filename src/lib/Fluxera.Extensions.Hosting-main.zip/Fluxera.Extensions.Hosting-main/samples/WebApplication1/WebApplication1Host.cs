﻿namespace WebApplication1
{
	using Fluxera.Extensions.Hosting;

	public class WebApplication1Host : WebApplicationHost<WebApplication1Module>
	{
	}
}
