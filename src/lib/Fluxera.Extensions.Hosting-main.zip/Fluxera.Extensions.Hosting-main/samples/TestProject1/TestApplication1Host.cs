﻿namespace TestProject1
{
	using Fluxera.Extensions.Hosting;
	using WebApplication1;

	public class TestApplication1Host : TestApplicationHost<WebApplication1Module>
	{
	}
}
