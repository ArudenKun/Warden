﻿namespace Fluxera.Extensions.Hosting.UnitTests
{
	using FluentAssertions;
	using NUnit.Framework;

	[TestFixture]
	public class ServiceCollectionTests
	{
		[Test]
		public void Should()
		{
			true.Should().BeTrue();
		}
	}
}
