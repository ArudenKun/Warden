﻿namespace Fluxera.Extensions.Hosting.UnitTests.DependsOn.Modules
{
	public class DependsOnThirdModule : DependsOnAttribute<ThirdModule>
	{
	}
}
