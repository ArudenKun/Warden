﻿namespace Fluxera.Extensions.Hosting.UnitTests.DependsOn.Modules
{
	using Fluxera.Extensions.Hosting.Modules;

	[DependsOnThirdModule]
	public class SecondModule : IModule
	{
	}
}
