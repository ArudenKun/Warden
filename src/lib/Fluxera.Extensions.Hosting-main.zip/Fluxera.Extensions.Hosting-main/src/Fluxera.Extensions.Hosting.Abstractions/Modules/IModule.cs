﻿namespace Fluxera.Extensions.Hosting.Modules
{
	using JetBrains.Annotations;

	/// <summary>
	///     A marker interface for modules.
	/// </summary>
	[PublicAPI]
	public interface IModule
	{
	}
}
